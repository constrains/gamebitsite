export default function sitemap() {
    return [
        {
            url: 'https://gamebitstudio.com',
            lastModified: new Date(),
            priority: 1,
        },
    ]
}